import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.tsx", "./components/**/*.tsx"],
  theme: { extend: {
    colors: { paper: "#F2F4F8", ink: "#0C1A33", blue: "#2748F5", sun: "#FFB400", mist: "#DDE3EE" },
    fontFamily: { display: ["var(--f-display)", "sans-serif"], body: ["var(--f-body)", "sans-serif"] },
  } },
  plugins: [],
} satisfies Config;
