# Muhammad Haider Butt: marketing site
`npm install && npm run dev` then open http://localhost:3000
- Leads (form and chatbot) post to `app/api/lead/route.ts`. Currently logs only; connect email/CRM there.
- Replace placeholder portfolio and testimonials with real, verified content.
- Chatbot is rule-based (no API key needed); swap in an LLM call later if wanted.
