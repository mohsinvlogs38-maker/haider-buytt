"use client";
import { useState } from "react";
const f = "w-full rounded-xl border border-mist bg-white px-4 py-3 focus:border-blue";
export default function ContactForm() {
  const [s, setS] = useState<"idle" | "sending" | "ok" | "err">("idle");
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setS("sending");
    const data = Object.fromEntries(new FormData(e.currentTarget));
    try {
      const r = await fetch("/api/lead", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ source: "form", ...data }) });
      setS(r.ok ? "ok" : "err");
    } catch { setS("err"); }
  }
  if (s === "ok") return <p role="status" className="rounded-2xl bg-white p-8 font-semibold">Thanks! Your request is in. Expect a reply within one working day.</p>;
  return (
    <form onSubmit={submit} className="grid gap-4 rounded-2xl bg-white p-6 sm:grid-cols-2 sm:p-8">
      <label className="grid gap-1 text-sm font-medium">Name<input name="name" required autoComplete="name" className={f} /></label>
      <label className="grid gap-1 text-sm font-medium">Business<input name="business" required className={f} /></label>
      <label className="grid gap-1 text-sm font-medium">Email<input name="email" type="email" required autoComplete="email" className={f} /></label>
      <label className="grid gap-1 text-sm font-medium">Phone / WhatsApp<input name="phone" type="tel" autoComplete="tel" className={f} /></label>
      <label className="grid gap-1 text-sm font-medium sm:col-span-2">Service needed
        <select name="service" className={f}>{["Meta Ads","Google Ads","LinkedIn Ads","Snapchat Ads","TikTok Ads","Shopify","Canva design","Not sure yet"].map(o => <option key={o}>{o}</option>)}</select></label>
      <label className="grid gap-1 text-sm font-medium sm:col-span-2">Tell me about your goals<textarea name="message" rows={4} className={f} /></label>
      <button disabled={s === "sending"} className="btn bg-blue text-white sm:col-span-2">{s === "sending" ? "Sending…" : "Get my free ad review"}</button>
      {s === "err" && <p role="alert" className="text-sm text-red-600 sm:col-span-2">Could not send. Please use WhatsApp or email instead.</p>}
    </form>
  );
}
