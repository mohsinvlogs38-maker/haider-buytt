"use client";
import { useRef, useState, useEffect } from "react";
type M = { from: "bot" | "me"; text: string };
const STEPS = [
  ["name", "Great, let's get you a proposal. What's your name?"],
  ["business", "What's your business name?"],
  ["type", "What type of business is it (e.g. clothing store, clinic, B2B software)?"],
  ["service", "Which service do you need? Meta, Google, LinkedIn, Snapchat, TikTok, Shopify or Canva?"],
  ["budget", "What's your approximate monthly advertising budget?"],
  ["contact", "Last one: what's the best phone, WhatsApp or email to reach you?"],
] as const;
const FAQ: [RegExp, string][] = [
  [/meta|facebook|instagram/i, "Meta Ads: campaign setup, creatives, audiences, pixel/conversion tracking and ongoing optimisation across Facebook and Instagram."],
  [/google|search|youtube/i, "Google Ads: search and display campaigns built around buyer intent, with keyword research and conversion tracking."],
  [/linkedin|b2b/i, "LinkedIn Ads: targeting by job title, industry and company size, best suited to B2B lead generation."],
  [/snap/i, "Snapchat Ads: short-form campaigns reaching younger audiences."],
  [/tiktok/i, "TikTok Ads: creative-led video campaigns for awareness and sales."],
  [/shopify|store|ecommerce/i, "Shopify: store design, product setup and day-to-day management so your ads land on a page that converts."],
  [/canva|design|creative/i, "Canva design: ad creatives, social posts and brand assets, made ready to run."],
  [/price|cost|fee|charge/i, "Pricing depends on platforms and scope. Share your details and Haider will send a custom quote. I can't quote exact figures here."],
  [/result|roi|guarantee/i, "No one can honestly guarantee results. Haider sets goals after reviewing your account and market."],
];
export default function Chat() {
  const [msgs, setMsgs] = useState<M[]>([{ from: "bot", text: "Hi! I'm the AI Marketing Assistant. Ask about any service, or type “quote” to start a free proposal request." }]);
  const [step, setStep] = useState(-1);
  const [lead, setLead] = useState<Record<string, string>>({});
  const [v, setV] = useState("");
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ block: "nearest" }); }, [msgs]);
  const add = (...m: M[]) => setMsgs(p => [...p, ...m]);
  async function send(e: React.FormEvent) {
    e.preventDefault();
    const t = v.trim(); if (!t) return; setV("");
    if (step >= 0) {
      const next = { ...lead, [STEPS[step][0]]: t }; setLead(next);
      if (step + 1 < STEPS.length) { add({ from: "me", text: t }, { from: "bot", text: STEPS[step + 1][1] }); setStep(step + 1); }
      else {
        add({ from: "me", text: t });
        const r = await fetch("/api/lead", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ source: "chatbot", ...next }) }).catch(() => null);
        add({ from: "bot", text: r?.ok ? `Thanks ${next.name}! Haider will contact you shortly.` : "I couldn't save that. Please use the WhatsApp or email buttons instead." });
        setStep(-1); setLead({});
      }
      return;
    }
    if (/quote|proposal|start|hire|book|call/i.test(t)) { add({ from: "me", text: t }, { from: "bot", text: STEPS[0][1] }); setStep(0); return; }
    const hit = FAQ.find(([re]) => re.test(t));
    add({ from: "me", text: t }, { from: "bot", text: (hit?.[1] ?? "I can explain any of the 7 services. Type “quote” to share your details for a proposal.") });
  }
  return (
    <div className="flex h-[26rem] flex-col rounded-2xl bg-white text-ink shadow-xl">
      <div className="flex-1 space-y-3 overflow-y-auto p-4" role="log" aria-live="polite">
        {msgs.map((m, i) => <p key={i} className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm ${m.from === "bot" ? "bg-paper" : "ml-auto bg-blue text-white"}`}>{m.text}</p>)}
        <div ref={end} />
      </div>
      <form onSubmit={send} className="flex gap-2 border-t border-mist p-3">
        <input value={v} onChange={e => setV(e.target.value)} aria-label="Your message" placeholder="Type here…" className="min-w-0 flex-1 rounded-full border border-mist px-4 py-2" />
        <button className="btn bg-ink px-5 py-2 text-white">Send</button>
      </form>
    </div>
  );
}
