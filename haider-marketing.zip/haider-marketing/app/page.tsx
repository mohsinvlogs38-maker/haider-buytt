import Chat from "@/components/Chat";
import ContactForm from "@/components/ContactForm";

const WA = "https://wa.me/923271918966?text=Hi%20Haider%2C%20I%27d%20like%20to%20discuss%20digital%20marketing.";
const MAIL = "mailto:butthafihaider@gmail.com";
const services = [
  ["Meta Ads", "Facebook and Instagram campaigns from creative to conversion tracking."],
  ["Google Ads", "Search and display ads that reach people already looking to buy."],
  ["LinkedIn Ads", "B2B targeting by role, industry and company size."],
  ["Snapchat Ads", "Short-form ads for younger, mobile-first audiences."],
  ["TikTok Ads", "Native-feeling video campaigns built for the feed."],
  ["Shopify Stores", "Store design and day-to-day management that turns clicks into orders."],
  ["Canva Design", "Ad creatives, social posts and brand assets, ready to publish."],
];
const why = [
  ["One person, direct access", "You talk to the marketer running your ads, with no account-manager layers."],
  ["Ads and store together", "Ad campaigns and the Shopify store are handled together, so traffic lands on a page built to convert."],
  ["Every platform in one place", "Meta, Google, LinkedIn, Snapchat and TikTok managed under one strategy."],
  ["Plain reporting", "You see what was spent, what it produced and what happens next."],
];
const steps = [
  ["Strategy", "Goals, audience, offer and budget defined before any money is spent."],
  ["Launch", "Tracking, creatives and campaigns set up and published."],
  ["Optimize", "Budgets, audiences and ads adjusted using real performance data."],
  ["Scale", "Winning campaigns expanded across audiences and platforms."],
];
const faq = [
  ["Which platforms do you run ads on?", "Meta (Facebook and Instagram), Google, LinkedIn, Snapchat and TikTok."],
  ["What budget do I need?", "It depends on your market and goals. Share your monthly budget and I'll recommend a realistic plan."],
  ["Do you also build my store or creatives?", "Yes. Shopify design and management and Canva design are both available."],
  ["Can you guarantee results?", "No honest marketer can. I set clear goals and report on progress openly."],
  ["How do I get started?", "Send the form, WhatsApp or email. You'll get a free review of your current marketing."],
];
const cases = ["Fashion store: Meta Ads", "Local service: Google Ads", "B2B firm: LinkedIn Ads"];

export default function Home() {
  return (
    <>
      <header className="sticky top-0 z-40 border-b border-mist bg-paper/90 backdrop-blur">
        <nav aria-label="Main" className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#top" className="font-display text-lg font-bold">Haider Butt</a>
          <ul className="hidden gap-7 text-sm font-medium md:flex">
            {["services", "process", "work", "faq", "contact"].map(i => <li key={i}><a href={`#${i}`} className="capitalize hover:text-blue">{i}</a></li>)}
          </ul>
          <a href={WA} className="btn hidden bg-ink py-2 text-sm text-white md:inline-flex">WhatsApp me</a>
          <details className="relative md:hidden">
            <summary className="btn cursor-pointer list-none bg-ink py-2 text-sm text-white" aria-label="Open menu">Menu</summary>
            <ul className="absolute right-0 mt-2 grid w-48 gap-3 rounded-2xl bg-white p-5 font-medium shadow-xl">
              {["services", "process", "work", "faq", "contact"].map(i => <li key={i}><a href={`#${i}`} className="capitalize">{i}</a></li>)}
            </ul>
          </details>
        </nav>
      </header>

      <main id="top">
        <section className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 md:grid-cols-2 md:py-24">
          <div className="rise">
            <p className="mb-4 font-semibold text-blue">Muhammad Haider Butt, Digital Marketer</p>
            <h1 className="font-display text-4xl font-extrabold leading-[1.05] sm:text-6xl">Grow Your Business With Smarter Digital Marketing</h1>
            <p className="mt-6 max-w-md text-lg text-ink/75">I plan, launch and manage paid campaigns on Meta, Google, LinkedIn, Snapchat and TikTok, and build the Shopify stores and Canva creatives that support them.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#contact" className="btn bg-blue text-white">Get a free ad review</a>
              <a href={WA} className="btn border-2 border-ink">Chat on WhatsApp</a>
            </div>
          </div>
          <div className="rise rounded-3xl bg-ink p-6 text-white" style={{ animationDelay: ".2s" }} aria-label="Sample campaign dashboard illustration">
            <div className="flex items-center justify-between text-sm"><span className="font-semibold">Campaign overview</span><span className="rounded-full bg-sun px-3 py-1 font-semibold text-ink">Sample illustration</span></div>
            <div className="mt-8 flex h-44 items-end gap-3" aria-hidden>
              {[30, 45, 38, 60, 52, 78, 95].map((h, i) => <div key={i} className="bar flex-1 rounded-t-lg bg-blue" style={{ height: `${h}%`, animationDelay: `${0.4 + i * 0.08}s`, background: i === 6 ? "#FFB400" : undefined }} />)}
            </div>
            <div className="mt-6 flex flex-wrap gap-2 text-xs">{["Meta", "Google", "LinkedIn", "Snapchat", "TikTok"].map(p => <span key={p} className="rounded-full border border-white/25 px-3 py-1">{p}</span>)}</div>
            <p className="mt-4 text-xs text-white/60">Decorative graphic. Not real client data.</p>
          </div>
        </section>

        <section id="services" className="bg-white py-20">
          <div className="mx-auto max-w-6xl px-5">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">Services</h2>
            <p className="mt-3 max-w-xl text-ink/70">Seven ways I help businesses get found, get clicks and get customers.</p>
            <div className="mt-10 grid gap-x-10 sm:grid-cols-2">
              {services.map(([t, d]) => (
                <div key={t} className="border-t border-mist py-6">
                  <h3 className="font-display text-xl font-bold">{t}</h3>
                  <p className="mt-2 text-ink/70">{d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-20">
          <h2 className="font-display text-3xl font-bold sm:text-4xl">Why choose me</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-4">
            {why.map(([t, d], i) => (
              <div key={t} className={`rounded-2xl p-6 ${i === 0 ? "bg-blue text-white" : "bg-white"}`}>
                <h3 className="font-display text-lg font-bold">{t}</h3>
                <p className={`mt-2 text-sm ${i === 0 ? "text-white/85" : "text-ink/70"}`}>{d}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="process" className="bg-ink py-20 text-white">
          <div className="mx-auto max-w-6xl px-5">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">How it works</h2>
            <ol className="mt-10 grid gap-8 md:grid-cols-4">
              {steps.map(([t, d], i) => (
                <li key={t}>
                  <span className="font-display text-5xl font-extrabold text-sun">{i + 1}</span>
                  <h3 className="mt-2 font-display text-xl font-bold">{t}</h3>
                  <p className="mt-2 text-white/70">{d}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id="work" className="mx-auto max-w-6xl px-5 py-20">
          <h2 className="font-display text-3xl font-bold sm:text-4xl">Selected work</h2>
          <p className="mt-3 rounded-lg bg-sun/30 px-4 py-2 text-sm font-medium">Placeholder projects. Replace with real case studies and verified results.</p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {cases.map(c => (
              <article key={c} className="rounded-2xl border-2 border-dashed border-ink/25 p-6">
                <div className="mb-5 grid h-32 place-items-center rounded-xl bg-mist text-sm text-ink/50">Project image placeholder</div>
                <h3 className="font-display text-lg font-bold">{c}</h3>
                <p className="mt-2 text-sm text-ink/70">[Goal, approach and results to be added.]</p>
              </article>
            ))}
          </div>
        </section>

        <section className="bg-white py-20">
          <div className="mx-auto max-w-6xl px-5">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">Client feedback</h2>
            <p className="mt-3 rounded-lg bg-sun/30 px-4 py-2 text-sm font-medium">Placeholder testimonials. Not from real clients.</p>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {[1, 2, 3].map(n => (
                <figure key={n} className="rounded-2xl bg-paper p-6">
                  <blockquote className="text-ink/70">[Testimonial {n} placeholder: add a real client quote here.]</blockquote>
                  <figcaption className="mt-4 text-sm font-semibold">[Client name, business]</figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl gap-10 px-5 py-20 md:grid md:grid-cols-2">
          <div>
            <h2 className="font-display text-3xl font-bold sm:text-4xl">AI Marketing Assistant</h2>
            <p className="mt-3 max-w-md text-ink/70">Ask about any service, or let the assistant collect your details so I can send a tailored proposal.</p>
          </div>
          <div className="mt-8 md:mt-0"><Chat /></div>
        </section>

        <section id="faq" className="bg-white py-20">
          <div className="mx-auto max-w-3xl px-5">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">Questions</h2>
            <div className="mt-8 divide-y divide-mist border-y border-mist">
              {faq.map(([q, a]) => (
                <details key={q} className="group py-4">
                  <summary className="cursor-pointer list-none font-semibold">{q}</summary>
                  <p className="mt-2 text-ink/70">{a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="bg-blue py-20 text-white">
          <div className="mx-auto grid max-w-6xl gap-10 px-5 md:grid-cols-5">
            <div className="md:col-span-2">
              <h2 className="font-display text-3xl font-bold sm:text-4xl">Let's talk about your growth</h2>
              <p className="mt-4 text-white/85">Send your details for a free review of your ads and store.</p>
              <div className="mt-6 flex flex-col gap-3">
                <a href={WA} className="btn bg-white text-ink">WhatsApp: 03271918966</a>
                <a href={MAIL} className="btn border-2 border-white">Email me</a>
              </div>
            </div>
            <div className="text-ink md:col-span-3"><ContactForm /></div>
          </div>
        </section>
      </main>

      <footer className="bg-ink py-10 text-sm text-white/80">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-5 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} Muhammad Haider Butt, Digital Marketer</p>
          <p><a href="tel:03271918966" className="underline">03271918966</a> · <a href={MAIL} className="underline">butthafihaider@gmail.com</a></p>
        </div>
      </footer>
    </>
  );
}
