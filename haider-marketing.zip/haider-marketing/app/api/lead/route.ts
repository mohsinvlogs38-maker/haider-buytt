import { NextResponse } from "next/server";
// TODO: forward leads to email (Resend/Nodemailer), Google Sheets or a CRM.
export async function POST(req: Request) {
  const lead = await req.json().catch(() => null);
  if (!lead || typeof lead !== "object" || !(lead.contact || lead.email || lead.phone))
    return NextResponse.json({ ok: false, error: "Contact details are required." }, { status: 400 });
  console.log("NEW LEAD", JSON.stringify(lead));
  return NextResponse.json({ ok: true });
}
