import type { Metadata } from "next";
import { Bricolage_Grotesque, DM_Sans } from "next/font/google";
import "./globals.css";
const d = Bricolage_Grotesque({ subsets: ["latin"], variable: "--f-display" });
const b = DM_Sans({ subsets: ["latin"], variable: "--f-body" });
export const metadata: Metadata = {
  title: "Muhammad Haider Butt | Digital Marketer: Meta, Google, TikTok & Shopify",
  description: "Digital marketer managing Meta, Google, LinkedIn, Snapchat and TikTok Ads, plus Shopify stores and Canva design. Get a free ad-account review.",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  const ld = { "@context": "https://schema.org", "@type": "ProfessionalService", name: "Muhammad Haider Butt", telephone: "+923271918966", email: "butthafihaider@gmail.com", serviceType: "Digital marketing" };
  return (
    <html lang="en" className={`${d.variable} ${b.variable}`}>
      <body>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
        {children}
      </body>
    </html>
  );
}
